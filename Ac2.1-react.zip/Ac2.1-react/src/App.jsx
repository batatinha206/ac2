import React from 'react';
import Header from './components/Header';
import Presentation from './components/Presentation';
import Skills from './components/Skills';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div>
      <Header />
      <main>
        <Presentation />
        <Skills />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
