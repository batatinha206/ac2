import React from 'react';

function Presentation() {
  return (
    <section>
      <h2>Apresentação Pessoal</h2>
      <p>Olá! Meu nome é Eric Haipeng Ye e sou por designer grafico, historia e games mobile.</p>
    </section>
  );
}

export default Presentation;
