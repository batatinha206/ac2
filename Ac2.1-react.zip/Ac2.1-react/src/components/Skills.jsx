import React from 'react';

function Skills() {
  return (
    <section>
      <h2>Principais Habilidades</h2>
      <div>
        <h3>designer grafico</h3>
        <p>Tenho um pouco de dominio de designer grafico</p>
      </div>
    </section>
  );
}

export default Skills;
